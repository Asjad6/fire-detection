#pip install Flask-Navigation

from flask import Flask, render_template
from flask_navigation import Navigation
from flask import request
import requests
import pandas as pd
import numpy as np
import datetime
import time
import pickle
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestClassifier, VotingClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics
import random
from xgboost import XGBRegressor
import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.regularizers import l1, l2, l1_l2

app = Flask(__name__)
nav = Navigation(app)
nav.Bar('top', [
    nav.Item('Home', 'index'),
    nav.Item('Gfg', 'gfg', {'page': 5}),
])


@app.route('/')
def index():
	return render_template('index.html')


@app.route('/overview')
def index1():
	return render_template('index.html')


@app.route('/data')
def navpage2():
	return render_template('data.html')

@app.route('/demo')
def navpage3():


    try: 

        city=request.args.get('search')
        print("search====>",city)
        df=pd.read_excel("CityID.xlsx")
        df['City name']=df['City name'].str.lower()
        df=df[df['City name'].isin([city.lower()])]
        if len(df)>0:
            for index, row in df.iterrows():
                print(row['City ID'],row['Latitude'],row['Longitude'],row['City name'])
                filename = 'randomforest.sav'
                reslist=[]
                URL="http://history.openweathermap.org/data/2.5/history/city?id="+str(row['City ID'])+"&type=daily&appid=71ac2af39d93330a7cf2bed42ffc2b22"
                res = requests.get(URL)
                res=res.json()["list"]
                for r in res:
                    reslist.append({"avgtempF":r["main"]["temp"] ,"totalSnow":0,"humid":r["main"]["humidity"],"wind":r["wind"]["speed"],"precip":0})
                    
                df=pd.DataFrame(reslist)

                #number=random.randint(0,len(df)-1)
                # load the model from disk
                rf = pickle.load(open(filename, 'rb'))
                res=""
                inputparameters="Data: (Temp= "+str(r["main"]["temp"])+" , Humid= "+str(r["main"]["humidity"])+" , wind= "+ str(r["wind"]["speed"])+" )"
                print(inputparameters)
                print(city)
                print(row['Latitude'],row['Longitude'])
                rf_preds = rf.predict(df.iloc[[23]])
                marker=""
                if rf_preds[0]==0:
                    marker="No Fire"
                    print("No Fire")
                else:
                    marker="Fire"
                    print("Fire")
                
                return render_template('demo.html',res=marker,data=inputparameters,lat=float(row['Latitude']),long=float(row['Longitude']),City="Location: "+city)

        else:
            
            return render_template('demo.html',res="No Result Found !!!!!!!",data="No Data found",lat="",long="",City="Location: "+city)




    except:
        print("except")
        return render_template('demo.html',res="No Result Found !!!!!!!",data="No Data found",lat="",long="",City="Location: Nothing Searched")
        pass

    

    

@app.route('/code')
def navpage4():
	return render_template('code.html')




if __name__ == '__main__':
	app.run(debug=True)
